package a2_1901040159;

public class CourseManProg {
    public static void main(String[] args) {
        CourseMan cm = new CourseMan();
        cm.display();
    }
}
