package a2_1901040159;

public class EnrolmentException extends Exception{
    public EnrolmentException(String message) {
        super(message);
    }
}
